
<?php

//load.php

$connect = new PDO('mysql:host=localhost;dbname=demo', 'root', '');

$data = array();

$query = "SELECT * FROM holidays ORDER BY id";

$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

foreach($result as $row)
{
 $data[] = array(
  'id'   => $row["id"],
  'title'   => $row["reason"],
  'start'   => $row["date"]
 );
}

echo json_encode($data);

?>